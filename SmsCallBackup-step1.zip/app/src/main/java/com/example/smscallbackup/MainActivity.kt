package com.example.smscallbackup

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.smscallbackup.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requiredPermissions = arrayOf(
        Manifest.permission.READ_SMS,
        Manifest.permission.READ_CALL_LOG
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            setStatus("Permissions granted ✔")
        } else {
            setStatus("Permissions denied — the app cannot read SMS/Calls without them.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRequestPermissions.setOnClickListener {
            if (hasAllPermissions()) {
                setStatus("Permissions already granted ✔")
            } else {
                permissionLauncher.launch(requiredPermissions)
            }
        }

        binding.btnExportNow.setOnClickListener { exportNow() }
    }

    private fun exportNow() {
        if (!hasAllPermissions()) {
            setStatus("Grant SMS/Call permissions first (step 1).")
            return
        }
        binding.btnExportNow.isEnabled = false
        setStatus("Exporting…")

        val ctx = applicationContext
        Thread {
            val message = try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val smsCount = DownloadsSaver.save(ctx, "sms_backup_$stamp.csv") {
                    SmsCallExporter.writeSms(ctx, it)
                }
                val callCount = DownloadsSaver.save(ctx, "calls_backup_$stamp.csv") {
                    SmsCallExporter.writeCallLog(ctx, it)
                }
                "Done ✔\n$smsCount SMS and $callCount calls saved in the Download folder:\n" +
                    "sms_backup_$stamp.csv\ncalls_backup_$stamp.csv"
            } catch (e: Exception) {
                "Export failed: ${e.message}"
            }
            runOnUiThread {
                setStatus(message)
                binding.btnExportNow.isEnabled = true
            }
        }.start()
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun setStatus(text: String) {
        binding.tvStatus.text = text
    }
}
