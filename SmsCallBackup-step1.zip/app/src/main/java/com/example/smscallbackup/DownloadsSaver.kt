package com.example.smscallbackup

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.IOException
import java.io.OutputStream

/** Saves a file into the public Download folder via MediaStore (Android 10+, no storage permission needed). */
object DownloadsSaver {

    /**
     * Creates [fileName] in Download and lets [writeBlock] fill it.
     * Returns whatever [writeBlock] returns (here: the number of rows written).
     */
    fun save(context: Context, fileName: String, writeBlock: (OutputStream) -> Int): Int {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create file in Downloads")

        try {
            val result = resolver.openOutputStream(uri)?.use { writeBlock(it) }
                ?: throw IOException("Could not open file for writing")
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            return result
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }
}
