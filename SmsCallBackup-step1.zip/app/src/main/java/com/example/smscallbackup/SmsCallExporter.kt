package com.example.smscallbackup

import android.content.Context
import android.provider.CallLog
import android.provider.Telephony
import java.io.BufferedWriter
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Reads SMS (inbox + sent) and the call log from the device's own content
 * providers and writes them as CSV into any OutputStream (a file, MediaStore,
 * or later a network socket). The stream is flushed but NOT closed here;
 * the caller owns it.
 *
 * A UTF-8 BOM is written first so Excel shows Persian text correctly.
 */
object SmsCallExporter {

    private const val BOM = "\uFEFF"

    private fun csvEscape(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    private fun newWriter(out: OutputStream) =
        BufferedWriter(OutputStreamWriter(out, Charsets.UTF_8))

    /** Returns the number of SMS rows written. */
    fun writeSms(context: Context, out: OutputStream): Int {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val writer = newWriter(out)
        var count = 0
        writer.write(BOM)
        writer.write("Date,Type,Address,Body")
        writer.newLine()

        val cursor = context.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
            null, null,
            "${Telephony.Sms.DATE} DESC"
        )

        cursor?.use {
            val dateIdx = it.getColumnIndexOrThrow(Telephony.Sms.DATE)
            val typeIdx = it.getColumnIndexOrThrow(Telephony.Sms.TYPE)
            val addrIdx = it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
            val bodyIdx = it.getColumnIndexOrThrow(Telephony.Sms.BODY)

            while (it.moveToNext()) {
                val date = dateFormat.format(Date(it.getLong(dateIdx)))
                val type = when (it.getInt(typeIdx)) {
                    Telephony.Sms.MESSAGE_TYPE_INBOX -> "Received"
                    Telephony.Sms.MESSAGE_TYPE_SENT -> "Sent"
                    else -> "Other"
                }
                val address = it.getString(addrIdx) ?: ""
                val body = it.getString(bodyIdx) ?: ""

                writer.write("${csvEscape(date)},${csvEscape(type)},${csvEscape(address)},${csvEscape(body)}")
                writer.newLine()
                count++
            }
        }
        writer.flush()
        return count
    }

    /** Returns the number of call-log rows written. */
    fun writeCallLog(context: Context, out: OutputStream): Int {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val writer = newWriter(out)
        var count = 0
        writer.write(BOM)
        writer.write("Date,Type,Number,DurationSeconds")
        writer.newLine()

        val cursor = context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.DATE, CallLog.Calls.TYPE, CallLog.Calls.NUMBER, CallLog.Calls.DURATION),
            null, null,
            "${CallLog.Calls.DATE} DESC"
        )

        cursor?.use {
            val dateIdx = it.getColumnIndexOrThrow(CallLog.Calls.DATE)
            val typeIdx = it.getColumnIndexOrThrow(CallLog.Calls.TYPE)
            val numberIdx = it.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
            val durationIdx = it.getColumnIndexOrThrow(CallLog.Calls.DURATION)

            while (it.moveToNext()) {
                val date = dateFormat.format(Date(it.getLong(dateIdx)))
                val type = when (it.getInt(typeIdx)) {
                    CallLog.Calls.INCOMING_TYPE -> "Incoming"
                    CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                    CallLog.Calls.MISSED_TYPE -> "Missed"
                    CallLog.Calls.REJECTED_TYPE -> "Rejected"
                    else -> "Other"
                }
                val number = it.getString(numberIdx) ?: ""
                val duration = it.getLong(durationIdx)

                writer.write("${csvEscape(date)},${csvEscape(type)},${csvEscape(number)},$duration")
                writer.newLine()
                count++
            }
        }
        writer.flush()
        return count
    }
}
