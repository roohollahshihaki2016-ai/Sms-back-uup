# ساخت APK از طریق GitHub Actions

1. ZIP را روی کامپیوتر/گوشی **استخراج** کن. محتویات (پوشه `app`، فایل‌های Gradle و پوشهٔ مخفی `.github`) باید مستقیماً در **ریشهٔ مخزن** باشند، نه داخل یک پوشه یا ZIP.
2. فایل‌های قدیمی مخزن را حذف کن (به‌خصوص `EmailSender.kt`، `BackupWorker.kt`، `BackupScheduler.kt`، `BootReceiver.kt`، `PrefsHelper.kt`) یا یک مخزن تازه بساز؛ وگرنه ساخت خطا می‌دهد.
3. در بخش **Actions** گردش‌کار **Build Android APK** را اجرا کن (Run workflow).
4. پس از اتمام، از **Artifacts** فایل `SmsCallBackup-debug-apk` را دانلود و از حالت ZIP خارج کن و `app-debug.apk` را نصب کن.

نسخهٔ Debug ساخته می‌شود (مناسب نصب شخصی). اگر نصب روی نسخهٔ قبلی خطا داد، نسخهٔ قبلی را حذف کن و دوباره نصب کن.
