# SMS & Call Backup (مرحله ۱: پاک‌سازی)

در این مرحله ایمیل، بک‌آپ روزانه و BootReceiver حذف شده‌اند. برنامه فقط:
1. مجوز خواندن پیامک و تماس می‌گیرد.
2. با دکمهٔ «Export CSV to Downloads» دو فایل CSV (پیامک و تماس‌ها) را در پوشهٔ Download ذخیره می‌کند.

فایل‌های CSV با UTF-8 BOM ساخته می‌شوند تا فارسی در Excel درست نمایش داده شود.
حداقل اندروید: ۱۰ (API 29).

برنامه فقط برای گوشی خودت است؛ فایل‌ها شامل اطلاعات خصوصی‌اند.

## ساختار
```
app/src/main/java/com/example/smscallbackup/
  MainActivity.kt      — صفحهٔ اصلی
  SmsCallExporter.kt   — خواندن پیامک/تماس و نوشتن CSV روی هر OutputStream
  DownloadsSaver.kt    — ذخیره در پوشهٔ Download با MediaStore
```
